
package com210.lab.q2;

import java.util.Scanner;
public class COM210LabQ2 
{

    
    public static void main(String[] args) 
    {
        Scanner scan = new Scanner(System.in);
        boolean peas = false;
        double x;
        double x1;
        double x2;
        double avg;
        String s;
        String s1;
        String s2;
        System.out.println("List the three items you are purchasing.");
        s = scan.nextLine();
        s1 = scan.nextLine();
        s2 = scan.nextLine();
        System.out.println("What are the prices of these three items?");
        x = scan.nextDouble();
        x1 = scan.nextDouble();
        x2 = scan.nextDouble();
        avg = (x + x1 + x2)/3;
        System.out.println("Item One: " + s + " " + x + ", " + "Item Two: " + s1 + " " + x1 + ", " + "Item Three: " + s2 + " " + x2);
        while(peas = false)
        {
            if(s == "peas")
            {
                peas = true;
                break;
            }
            else if(s1 == "peas")
            {
                peas = true;
                break;
            }
            else if(s2 == "peas")
            {
                peas = true;
                break;
            }
            else
            {
                peas = false;
            }
        }
        if(peas = true)
        {
            System.out.println("The average price of these items is: "+ avg);
        }
        else
        {
            System.out.println("No average output.");
        }

    }
    
}
