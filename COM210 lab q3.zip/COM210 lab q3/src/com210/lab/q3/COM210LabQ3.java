
package com210.lab.q3;

import java.util.Scanner;
public class COM210LabQ3 
{
        public static void main(String[] args) 
        {

        Scanner scan = new Scanner(System.in);
        int input;

        System.out.println("Enter the number of items that you want to process.");
        input = scan.nextInt();

        String itemNames[] = new String[input];
        double itemPrice[] = new double[input];

        for(int i=0;i<input;i++) 
        {
            System.out.println("Enter Item "+(i+1)+" details");
            System.out.print("Enter Item Name:");
            itemNames[i] = scan.next();
            System.out.print("Enter Item Price:");
            itemPrice[i] = scan.nextDouble();
        }


        System.out.println("Item details in reverse order:");
        System.out.println("Item Name \t Item Price");
        for(int i=input-1;i>=0;i--) 
        {
            System.out.println(itemNames[i]+"\t\t"+itemPrice[i]);
        }

        int totalItemsWithNamePeas=0;
        double avg;
        double sum =0;
        for(int i=0;i<input;i++)
        {
            if(itemNames[i].equalsIgnoreCase("Peas"))
            {
            sum = sum + itemPrice[i];
            totalItemsWithNamePeas++;
            }
        }
        avg = sum/totalItemsWithNamePeas;

        if(totalItemsWithNamePeas==0) 
        {
            System.out.println("no average output.");
        } 
        else 
        {
            System.out.println("Average price for your items is:"+avg);
        }

        }
        

    }
    

